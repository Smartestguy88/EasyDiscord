# EasyDiscord
Easy discord bot program, relying on pychord but aimed for significantly quicker and simpler bot development

To use, request personally (physically) the help of Smartguy88
If you do not know who I am, I would likely prefer it stay that way :)
